Run shell command:
mkdir -p .github/omni
Edit file
.github/omni/README.md
Edit file
github-push.sh
Run shell command:
chmod +x github-push.sh
Run shell command:
./github-push.sh