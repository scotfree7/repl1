
#!/bin/bash

# GitHub repository push script with proper structure
# Usage: ./github-push.sh

GITHUB_REPO="scotfree47/omni"
GITHUB_URL="https://github.com/${GITHUB_REPO}.git"

echo "🚀 Setting up GitHub repository: ${GITHUB_URL}"

# Check if git is initialized
if [ ! -d ".git" ]; then
  echo "📦 Initializing git repository..."
  git init
fi

# Configure git if needed
if [ -z "$(git config user.email)" ]; then
  echo "⚙️ Configuring git user..."
  git config user.email "your-email@example.com"
  git config user.name "Your Name"
fi

# Add all files excluding certain directories
echo "📝 Adding files to git..."
git add .
git reset -- node_modules/ dist/ "*.zip" "*.tar.gz"

# Commit changes
echo "💾 Committing changes..."
git commit -m "Initial commit with .github/omni structure" || {
  echo "ℹ️ No changes to commit or commit failed."
}

# Handle remote
if ! git remote | grep -q "origin"; then
  echo "🔗 Adding remote origin..."
  git remote add origin $GITHUB_URL
else
  echo "🔄 Updating remote URL..."
  git remote set-url origin $GITHUB_URL
fi

echo "🌟 Pushing to GitHub..."
echo "🔐 You will be prompted for your GitHub credentials."

git push -u origin main --force || {
  echo "❌ Failed to push to GitHub."
  echo ""
  echo "If you're having authentication issues, try with your Personal Access Token:"
  echo ""
  echo "1. Create a token at https://github.com/settings/tokens with 'repo' permissions"
  echo "2. Then run:"
  echo "   git remote set-url origin https://YOUR_USERNAME:YOUR_TOKEN@github.com/${GITHUB_REPO}.git"
  echo "   git push -u origin main"
  echo ""
  exit 1
}

echo "✅ Success! Your code is now on GitHub at: https://github.com/${GITHUB_REPO}"
echo "📋 The structure will be: omni (repository)/.github/omni (directory)"
