import React from 'react';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import UrlInput from '@/components/url-input';
import ExtractionTools from '@/components/extraction-tools';
import ExtractionStatus from '@/components/extraction-status';
import ExtractedContent from '@/components/extracted-content';
import QuickReference from '@/components/quick-reference';
import MyDogAteIt from '@/components/my-dog-ate-it';
import AiSandbox from '@/components/ai-sandbox';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';
import { ExtractionRequest, ExtractionStatus as Status } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { ArrowUpFromLine, Zap } from 'lucide-react';

export default function Home() {
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false);
  const [extractionStatus, setExtractionStatus] = useState<Status>('idle');
  const [progress, setProgress] = useState(0);
  const [url, setUrl] = useState('');
  const [selectedMethod, setSelectedMethod] = useState<'scraping' | 'browser' | 'api'>('scraping');
  const [logs, setLogs] = useState<string[]>([]);
  const [showExtractedContent, setShowExtractedContent] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const extractionMutation = useMutation({
    mutationFn: async (data: ExtractionRequest) => {
      const response = await apiRequest('POST', '/api/extract', data);
      return response.json();
    },
    onMutate: () => {
      setExtractionStatus('analyzing');
      setProgress(0);
      setLogs([`[${new Date().toLocaleTimeString()}] Starting extraction process for URL: ${url}`]);
      
      // Simulation of progress updates
      const progressInterval = setInterval(() => {
        setProgress((prev) => {
          const newProgress = prev + 5;
          if (newProgress >= 100) {
            clearInterval(progressInterval);
            setExtractionStatus('complete');
            setShowExtractedContent(true);
            return 100;
          }
          
          if (newProgress === 10) {
            setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] Analyzing page structure...`]);
          } else if (newProgress === 30) {
            setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] Detected content type: Website`]);
          } else if (newProgress === 50) {
            setExtractionStatus('extracting');
            setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] Selected extraction method: ${selectedMethod}`]);
          } else if (newProgress === 70) {
            setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] Identified main content container`]);
          } else if (newProgress === 90) {
            setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] Extraction in progress...`]);
          }
          
          return newProgress;
        });
      }, 300);
      
      return () => clearInterval(progressInterval);
    },
    onSuccess: (data) => {
      setExtractionStatus('complete');
      setProgress(100);
      setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] Extraction completed successfully`]);
      queryClient.invalidateQueries({ queryKey: ['/api/extract/content'] });
      toast({
        title: "Content extracted successfully",
        description: "The content has been extracted and formatted for you",
        variant: "success",
      });
    },
    onError: (error) => {
      setExtractionStatus('error');
      setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] Error: ${error.message}`]);
      toast({
        title: "Extraction failed",
        description: error.message || "Failed to extract content. Please try again.",
        variant: "destructive",
      });
    }
  });

  const extractedContentQuery = useQuery({
    queryKey: ['/api/extract/content', url],
    enabled: extractionStatus === 'complete',
  });

  const handleSubmit = (data: ExtractionRequest) => {
    setUrl(data.url);
    setShowExtractedContent(false);
    extractionMutation.mutate(data);
  };

  const toggleAdvancedOptions = () => {
    setShowAdvancedOptions(!showAdvancedOptions);
  };

  const selectExtractionMethod = (method: 'scraping' | 'browser' | 'api') => {
    setSelectedMethod(method);
  };

  const cancelExtraction = () => {
    extractionMutation.reset();
    setExtractionStatus('idle');
    setLogs([]);
  };
  
  const [myDogAteItResult, setMyDogAteItResult] = useState<string>('');
  const [currentTab, setCurrentTab] = useState('extractor');
  const [extractedToMyDogAteIt, setExtractedToMyDogAteIt] = useState<string>('');
  const [myDogAteItToExtractor, setMyDogAteItToExtractor] = useState<string>('');
  const [aiPrompt, setAiPrompt] = useState<string>('');
  const [autoProcessAi, setAutoProcessAi] = useState<boolean>(false);

  // Handler for MyDogAteIt processing
  const handleMyDogAteItProcess = (result: string) => {
    setMyDogAteItResult(result);
    
    // Set AI prompt with the result for analysis
    setAiPrompt(`Analyze and summarize the following content: ${result.substring(0, 500)}${result.length > 500 ? '...' : ''}`);
    setAutoProcessAi(true);
    setCurrentTab('aisandbox');
    
    toast({
      title: "MyDogAteIt Processing Complete",
      description: "The text has been processed according to the rules",
      variant: "success",
    });
  };

  // Handler for sending content from Extractor to MyDogAteIt
  const handleSendToMyDogAteIt = (content: string) => {
    setExtractedToMyDogAteIt(content);
    setCurrentTab('mydogateit');
  };

  // Handler for sending content from MyDogAteIt to Extractor
  const handleSendToExtractor = (content: string) => {
    setMyDogAteItToExtractor(content);
    setUrl("Custom content from MyDogAteIt");
    setExtractionStatus('complete');
    setProgress(100);
    setShowExtractedContent(true);
    setCurrentTab('extractor');
  };

  // Handler for AI model responses
  const handleModelResponse = (model: string, prompt: string, response: string) => {
    console.log(`Response from ${model}:`, response);
  };
  
  // Handler for AI processing completion
  const handleAiProcessComplete = (result: { model: string, prompt: string, response: string }) => {
    setAutoProcessAi(false);
    
    toast({
      title: `${result.model} Analysis Complete`,
      description: "The AI has analyzed your content",
      variant: "success",
    });
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-6">
        <Tabs value={currentTab} onValueChange={setCurrentTab} className="w-full mb-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="extractor">Extractor</TabsTrigger>
            <TabsTrigger value="mydogateit">MyDogAteIt</TabsTrigger>
            <TabsTrigger value="aisandbox">AI Sandbox</TabsTrigger>
          </TabsList>
          
          <TabsContent value="extractor">
            <UrlInput 
              onSubmit={handleSubmit}
              showAdvancedOptions={showAdvancedOptions} 
              toggleAdvancedOptions={toggleAdvancedOptions}
            />
            
            <ExtractionTools 
              selectedMethod={selectedMethod}
              onSelectMethod={selectExtractionMethod}
            />
            
            {extractionStatus !== 'idle' && (
              <ExtractionStatus 
                status={extractionStatus}
                url={url}
                progress={progress}
                logs={logs}
                onCancel={cancelExtraction}
              />
            )}
            
            {showExtractedContent && (
              <>
                <ExtractedContent 
                  loading={extractedContentQuery.isLoading}
                  content={myDogAteItToExtractor ? { content: myDogAteItToExtractor } : extractedContentQuery.data}
                />
                
                <div className="mt-4 flex justify-end">
                  <Button 
                    variant="outline"
                    size="sm"
                    className="bg-green-50 hover:bg-green-100 text-green-800 border-green-200"
                    onClick={() => {
                      // Handle possible content sources with proper type checking
                      let content = 'No content extracted';
                      
                      if (myDogAteItToExtractor) {
                        content = myDogAteItToExtractor;
                      } else if (extractedContentQuery.data && typeof extractedContentQuery.data === 'object') {
                        // Access content if it exists in the data object
                        const dataContent = (extractedContentQuery.data as any).content;
                        if (dataContent) {
                          content = dataContent;
                        }
                      }
                      
                      handleSendToMyDogAteIt(content);
                    }}
                  >
                    <ArrowUpFromLine className="h-4 w-4 mr-2" />
                    Send to MyDogAteIt
                  </Button>
                </div>
              </>
            )}
            
            <QuickReference />
          </TabsContent>
          
          <TabsContent value="mydogateit">
            <MyDogAteIt 
              onProcess={handleMyDogAteItProcess} 
              importedContent={extractedToMyDogAteIt}
              onExport={handleSendToExtractor}
            />
            
            {myDogAteItResult && (
              <div className="mt-4 p-4 border rounded-md bg-gray-50">
                <h3 className="text-lg font-medium mb-2">Processed Result</h3>
                <div className="whitespace-pre-wrap bg-white p-4 rounded border">
                  {myDogAteItResult}
                </div>
                <div className="mt-4 flex justify-end">
                  <Button 
                    variant="outline"
                    size="sm"
                    className="bg-blue-50 hover:bg-blue-100 text-blue-800 border-blue-200"
                    onClick={() => {
                      setAiPrompt(`Analyze this processed content: ${myDogAteItResult.substring(0, 500)}${myDogAteItResult.length > 500 ? '...' : ''}`);
                      setAutoProcessAi(true);
                      setCurrentTab('aisandbox');
                    }}
                  >
                    <Zap className="h-4 w-4 mr-2" />
                    Analyze with AI
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="aisandbox">
            <AiSandbox 
              onModelResponse={handleModelResponse}
              initialPrompt={aiPrompt}
              autoProcess={autoProcessAi}
              onProcessComplete={handleAiProcessComplete}
            />
          </TabsContent>
        </Tabs>
      </main>
      
      <Footer />
    </div>
  );
}
