import { apiRequest } from './queryClient';

export type TextStyle = 'casual' | 'formal' | 'academic' | 'creative';
export type TextLength = 'short' | 'medium' | 'long';

export interface UndetectableRequest {
  prompt: string;
  style?: TextStyle;
  length?: TextLength;
}

export interface UndetectableResponse {
  text: string;
  status: 'success' | 'error';
  message?: string;
}

/**
 * A service for generating human-like undetectable text
 */
export const undetectableService = {
  /**
   * Generate human-like text that won't be detected as AI-generated
   */
  async generateText(
    prompt: string,
    style: TextStyle = 'casual',
    length: TextLength = 'medium'
  ): Promise<UndetectableResponse> {
    const request: UndetectableRequest = {
      prompt,
      style,
      length
    };
    
    try {
      const response = await apiRequest('POST', '/api/undetectable/generate', request);
      return await response.json();
    } catch (error) {
      console.error('Error calling Undetectable API:', error);
      return {
        text: '',
        status: 'error',
        message: 'Failed to generate undetectable text'
      };
    }
  }
};