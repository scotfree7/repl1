import { apiRequest } from './queryClient';

// Types for Perplexity API
export type PerplexityModel = 
  | 'llama-3.1-sonar-small-128k-online'
  | 'llama-3.1-sonar-large-128k-online'
  | 'llama-3.1-sonar-huge-128k-online';

export type MessageRole = 'system' | 'user' | 'assistant';

export interface Message {
  role: MessageRole;
  content: string;
}

export interface PerplexityRequest {
  model: PerplexityModel;
  messages: Message[];
  temperature?: number;
  max_tokens?: number;
  stream?: boolean;
}

export interface PerplexityResponse {
  id: string;
  model: string;
  object: string;
  created: number;
  citations: string[];
  choices: {
    index: number;
    finish_reason: string;
    message: {
      role: string;
      content: string;
    };
    delta?: {
      role: string;
      content: string;
    };
  }[];
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

export interface PerplexityError {
  error: string;
  details?: any;
}

/**
 * A service for interacting with the Perplexity API
 */
export const perplexityService = {
  /**
   * Send a completion request to the Perplexity API
   */
  async generateCompletion(
    prompt: string,
    model: PerplexityModel = 'llama-3.1-sonar-small-128k-online',
    systemPrompt?: string
  ): Promise<PerplexityResponse> {
    // Create the messages array
    const messages: Message[] = [];
    
    // Add system prompt if provided
    if (systemPrompt) {
      messages.push({
        role: 'system',
        content: systemPrompt
      });
    }
    
    // Add user prompt
    messages.push({
      role: 'user',
      content: prompt
    });
    
    // Create the request
    const request: PerplexityRequest = {
      model,
      messages,
      temperature: 0.7
    };
    
    try {
      // Send request to our backend Perplexity API endpoint
      const response = await apiRequest('POST', '/api/perplexity/chat/completions', request);
      return await response.json();
    } catch (error) {
      console.error('Error calling Perplexity API:', error);
      throw error;
    }
  },
  
  /**
   * Send a chat request that continues a conversation
   */
  async generateChatCompletion(
    messages: Message[],
    model: PerplexityModel = 'llama-3.1-sonar-small-128k-online'
  ): Promise<PerplexityResponse> {
    // Create the request
    const request: PerplexityRequest = {
      model,
      messages,
      temperature: 0.7
    };
    
    try {
      // Send request to our backend Perplexity API endpoint
      const response = await apiRequest('POST', '/api/perplexity/chat/completions', request);
      return await response.json();
    } catch (error) {
      console.error('Error calling Perplexity API:', error);
      throw error;
    }
  },
  
  /**
   * Query analyzer - determines the type of query
   */
  analyzeQueryType(query: string): 'factual' | 'creative' | 'code' | 'analysis' {
    const lowerQuery = query.toLowerCase();
    if (lowerQuery.includes('code') || lowerQuery.includes('function') || lowerQuery.includes('programming')) {
      return 'code';
    } else if (lowerQuery.includes('explain') || lowerQuery.includes('analyze') || lowerQuery.includes('compare')) {
      return 'analysis';
    } else if (lowerQuery.includes('create') || lowerQuery.includes('write') || lowerQuery.includes('design')) {
      return 'creative';
    } else {
      return 'factual';
    }
  },
  
  /**
   * Get the most appropriate model based on query type
   */
  getBestModelForQueryType(queryType: 'factual' | 'creative' | 'code' | 'analysis'): PerplexityModel {
    // For now, all query types use the same model in simulation mode
    // In a real implementation, this could route to different Perplexity models
    return 'llama-3.1-sonar-small-128k-online';
  }
};