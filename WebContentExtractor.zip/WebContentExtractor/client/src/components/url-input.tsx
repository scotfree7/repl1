import React from 'react';
import { Link } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormField, FormItem, FormLabel } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { extractionRequestSchema, ExtractionRequest } from '@shared/schema';

interface UrlInputProps {
  onSubmit: (data: ExtractionRequest) => void;
  showAdvancedOptions: boolean;
  toggleAdvancedOptions: () => void;
}

const UrlInput: React.FC<UrlInputProps> = ({ onSubmit, showAdvancedOptions, toggleAdvancedOptions }) => {
  const form = useForm<ExtractionRequest>({
    resolver: zodResolver(extractionRequestSchema),
    defaultValues: {
      url: '',
      method: 'auto',
      dataSource: 'webpage',
      outputFormat: 'formatted',
      removeAds: true,
      includeImages: true,
    },
  });

  const handleSubmit = form.handleSubmit((data) => {
    onSubmit(data);
  });

  return (
    <section className="mb-8">
      <div className="bg-white p-4 rounded-lg shadow-md">
        <h2 className="text-lg font-semibold mb-3">Extract Web Content</h2>
        
        <Form {...form}>
          <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4">
            <div className="flex-grow">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Link className="h-5 w-5 text-secondary" />
                </div>
                <FormField
                  control={form.control}
                  name="url"
                  render={({ field }) => (
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="Enter URL to extract content (e.g. https://example.com)"
                        className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
                      />
                    </FormControl>
                  )}
                />
              </div>
              <div className="text-xs text-secondary mt-1">
                Recently used: 
                <a href="#" className="text-info hover:underline ml-1">nytimes.com/tech</a>, 
                <a href="#" className="text-info hover:underline ml-1">github.com/trending</a>
              </div>
            </div>
            
            <div className="flex items-start space-x-2">
              <Button 
                type="submit" 
                className="px-4 py-2 bg-primary text-white rounded-md hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-50"
              >
                Extract
              </Button>
              <Button 
                type="button" 
                variant="outline"
                className="p-2 text-secondary bg-gray-100 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-300"
                onClick={toggleAdvancedOptions}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>
              </Button>
            </div>
          </form>
        </Form>
        
        {showAdvancedOptions && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <h3 className="text-md font-medium mb-3">Advanced Options</h3>
            <Form {...form}>
              <form className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <FormField
                    control={form.control}
                    name="method"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="block text-sm font-medium text-secondary mb-1">Extraction Method</FormLabel>
                        <Select 
                          defaultValue={field.value} 
                          onValueChange={field.onChange}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select method" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="auto">Auto-detect (Recommended)</SelectItem>
                            <SelectItem value="scraping">Web Scraping</SelectItem>
                            <SelectItem value="browser">Browser Automation</SelectItem>
                            <SelectItem value="api">API Integration</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                </div>
                
                <div>
                  <FormField
                    control={form.control}
                    name="dataSource"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="block text-sm font-medium text-secondary mb-1">Data Source</FormLabel>
                        <Select 
                          defaultValue={field.value} 
                          onValueChange={field.onChange}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select source" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="webpage">Web Page</SelectItem>
                            <SelectItem value="reddit">Reddit</SelectItem>
                            <SelectItem value="postgres">PostgreSQL</SelectItem>
                            <SelectItem value="rss">RSS Feed</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                </div>
                
                <div>
                  <FormField
                    control={form.control}
                    name="outputFormat"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="block text-sm font-medium text-secondary mb-1">Output Format</FormLabel>
                        <Select 
                          defaultValue={field.value} 
                          onValueChange={field.onChange}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select format" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="formatted">Formatted Text</SelectItem>
                            <SelectItem value="json">JSON</SelectItem>
                            <SelectItem value="html">HTML</SelectItem>
                            <SelectItem value="markdown">Markdown</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="md:col-span-2">
                  <FormField
                    control={form.control}
                    name="selector"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="block text-sm font-medium text-secondary mb-1">Content Selection</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="w-full p-2 border border-gray-300 rounded-md font-mono text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                            placeholder="CSS Selector (e.g. article.main, #content)"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
                
                <div>
                  <FormField
                    control={form.control}
                    name="removeAds"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            className="rounded text-primary focus:ring-primary"
                          />
                        </FormControl>
                        <FormLabel className="text-sm text-secondary">Remove ads/tracking</FormLabel>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="includeImages"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-2 space-y-0 mt-2">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            className="rounded text-primary focus:ring-primary"
                          />
                        </FormControl>
                        <FormLabel className="text-sm text-secondary">Include images</FormLabel>
                      </FormItem>
                    )}
                  />
                </div>
              </form>
            </Form>
          </div>
        )}
      </div>
    </section>
  );
};

export default UrlInput;
