import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { Check, Loader2 } from 'lucide-react';
import { perplexityService } from "@/lib/perplexityService";

interface AiSandboxProps {
  onModelResponse?: (model: string, prompt: string, response: string) => void;
  initialPrompt?: string;
  autoProcess?: boolean;
  onProcessComplete?: (result: { prompt: string, model: string, response: string }) => void;
}

type ModelType = 
  | 'gpt-4.0' 
  | 'gpt-4.5' 
  | 'o3-mini'
  | 'o3-mini-high'
  | 'o1'
  | 'claude-3.5'
  | 'claude-3.7-sonnet'
  | 'perplexity-sonar';

interface ModelConfig {
  name: string;
  apiParam: string;
  description: string;
  provider: 'openai' | 'anthropic' | 'perplexity';
}

const modelConfigs: Record<ModelType, ModelConfig> = {
  'gpt-4.0': {
    name: 'GPT-4.0',
    apiParam: 'gpt-4o',
    description: 'OpenAI\'s GPT-4o - powerful general model with strong reasoning',
    provider: 'openai'
  },
  'gpt-4.5': {
    name: 'GPT-4.5',
    apiParam: 'gpt-4-turbo',
    description: 'OpenAI\'s latest model with enhanced capabilities',
    provider: 'openai'
  },
  'o3-mini': {
    name: 'O3-Mini',
    apiParam: 'o3-mini',
    description: 'Compact model with efficient performance',
    provider: 'openai'
  },
  'o3-mini-high': {
    name: 'O3-Mini High',
    apiParam: 'o3-mini-high',
    description: 'Enhanced version of O3-Mini with improved outputs',
    provider: 'openai'
  },
  'o1': {
    name: 'O1',
    apiParam: 'o1',
    description: 'Optimized for efficient, accurate responses',
    provider: 'openai'
  },
  'claude-3.5': {
    name: 'Claude 3.5',
    apiParam: 'claude-3-5-sonnet',
    description: 'Anthropic\'s Claude 3.5 model - balanced and efficient',
    provider: 'anthropic'
  },
  'claude-3.7-sonnet': {
    name: 'Claude 3.7 Sonnet',
    apiParam: 'claude-3-7-sonnet',
    description: 'Anthropic\'s latest sonnet model with enhanced capabilities',
    provider: 'anthropic'
  },
  'perplexity-sonar': {
    name: 'Perplexity Sonar',
    apiParam: 'llama-3.1-sonar-small-128k-online',
    description: 'Perplexity\'s latest search-augmented model',
    provider: 'perplexity'
  }
};

export default function AiSandbox({ 
  onModelResponse, 
  initialPrompt = '',
  autoProcess = false,
  onProcessComplete
}: AiSandboxProps) {
  const [selectedModel, setSelectedModel] = useState<ModelType>('perplexity-sonar');
  const [prompt, setPrompt] = useState(initialPrompt);
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState(initialPrompt ? 'prompt' : 'prompt');
  const [responseHistory, setResponseHistory] = useState<{model: ModelType, prompt: string, response: string}[]>([]);
  const [recommendedModel, setRecommendedModel] = useState<ModelType | null>(null);
  
  const { toast } = useToast();

  // Handle initial prompt and auto processing
  useEffect(() => {
    if (initialPrompt && initialPrompt !== prompt) {
      setPrompt(initialPrompt);
      if (autoProcess) {
        handleAutomaticProcessing(initialPrompt);
      }
    }
  }, [initialPrompt, autoProcess]);

  const handleModelChange = (value: string) => {
    setSelectedModel(value as ModelType);
  };

  // This function automatically routes the query through Perplexity first to determine the best model
  const handleAutomaticProcessing = async (userPrompt: string) => {
    if (!userPrompt.trim()) return;
    
    setLoading(true);
    setActiveTab('response');
    
    // First, send to Perplexity to analyze the query
    setTimeout(() => {
      // Simulated Perplexity analysis - would be a real API call
      const queryType = analyzeQueryType(userPrompt);
      const bestModel = selectBestModelForQuery(queryType);
      
      setRecommendedModel(bestModel);
      
      // If the best model is not Perplexity, send to that model
      if (bestModel !== 'perplexity-sonar') {
        simulateModelResponse(bestModel, userPrompt);
      } else {
        // If Perplexity is best, show its response directly
        completeSimulatedResponse('perplexity-sonar', userPrompt);
      }
    }, 1000);
  };

  // Analyze what type of query this is (would be done by Perplexity API in real implementation)
  const analyzeQueryType = (query: string): 'factual' | 'creative' | 'code' | 'analysis' => {
    const lowerQuery = query.toLowerCase();
    if (lowerQuery.includes('code') || lowerQuery.includes('function') || lowerQuery.includes('programming')) {
      return 'code';
    } else if (lowerQuery.includes('explain') || lowerQuery.includes('analyze') || lowerQuery.includes('compare')) {
      return 'analysis';
    } else if (lowerQuery.includes('create') || lowerQuery.includes('write') || lowerQuery.includes('design')) {
      return 'creative';
    } else {
      return 'factual';
    }
  };

  // Select the best model based on query type
  const selectBestModelForQuery = (queryType: 'factual' | 'creative' | 'code' | 'analysis'): ModelType => {
    switch (queryType) {
      case 'factual':
        return 'perplexity-sonar'; // Best for factual information
      case 'creative':
        return 'claude-3.7-sonnet'; // Best for creative writing
      case 'code':
        return 'gpt-4.0'; // Best for code
      case 'analysis':
        return 'o3-mini-high'; // Best for analysis
      default:
        return 'perplexity-sonar';
    }
  };

  // Simulate sending to another model after Perplexity recommendation
  const simulateModelResponse = (model: ModelType, userPrompt: string) => {
    setTimeout(() => {
      completeSimulatedResponse(model, userPrompt);
    }, 1500);
  };

  const completeSimulatedResponse = (model: ModelType, userPrompt: string) => {
    const modelInfo = modelConfigs[model];
    let simulatedResponse = '';
    
    if (model === 'perplexity-sonar') {
      simulatedResponse = `[Perplexity Analysis]
Based on your query: "${userPrompt}"

I've analyzed this as a ${analyzeQueryType(userPrompt)} type question.
${recommendedModel && recommendedModel !== 'perplexity-sonar' ? 
  `I'm routing this to ${modelConfigs[recommendedModel].name} for the best answer.` : 
  `I'll handle this query directly as it's best suited for search-augmented generation.`}

Response:
This is a simulated response from ${modelInfo.name} using the ${modelInfo.apiParam} model.
In a real implementation, you would receive actual search-augmented information from the Perplexity API.`;
    } else {
      simulatedResponse = `[Routed from Perplexity to ${modelInfo.name}]
      
Your query was determined to be a "${analyzeQueryType(userPrompt)}" type question, which ${modelInfo.name} specializes in.

Response from ${modelInfo.name}:
This is a simulated response using the ${modelInfo.apiParam} model from ${modelInfo.provider}.
In a real implementation, this would contain the actual response from the ${modelInfo.provider} API.`;
    }
    
    setResponse(simulatedResponse);
    setLoading(false);
    
    // Save to history
    setResponseHistory(prev => [
      { model, prompt: userPrompt, response: simulatedResponse },
      ...prev
    ]);
    
    if (onModelResponse) {
      onModelResponse(modelInfo.name, userPrompt, simulatedResponse);
    }

    if (onProcessComplete) {
      onProcessComplete({
        model: modelInfo.name,
        prompt: userPrompt,
        response: simulatedResponse
      });
    }
    
    toast({
      title: "Response received",
      description: `${modelInfo.name} has processed your prompt`,
      variant: "success",
    });
  };

  const handleSendPrompt = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt required",
        description: "Please enter a prompt to send to the model",
        variant: "destructive",
      });
      return;
    }

    handleAutomaticProcessing(prompt);
  };

  const handleClear = () => {
    setPrompt('');
    setResponse('');
  };

  return (
    <Card className="w-full mb-6 shadow-md">
      <CardHeader>
        <CardTitle className="text-lg font-medium">AI Model Sandbox</CardTitle>
        <CardDescription>
          Test and compare responses from different AI models
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <label className="block text-sm font-medium mb-1">Select Model</label>
          <Select onValueChange={handleModelChange} value={selectedModel}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select a model" />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(modelConfigs).map(([key, config]) => (
                <SelectItem key={key} value={key}>
                  <div className="flex flex-col">
                    <span>{config.name}</span>
                    <span className="text-xs text-gray-500">{config.description}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="prompt">Prompt</TabsTrigger>
            <TabsTrigger value="response">Response</TabsTrigger>
          </TabsList>
          <TabsContent value="prompt">
            <Textarea
              placeholder="Enter your prompt here..."
              className="min-h-[200px] w-full"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
            />
          </TabsContent>
          <TabsContent value="response">
            {loading ? (
              <div className="min-h-[200px] w-full flex items-center justify-center bg-gray-50 rounded-md">
                <div className="flex flex-col items-center">
                  <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
                  <p className="text-sm text-gray-500">Getting response from {modelConfigs[selectedModel].name}...</p>
                </div>
              </div>
            ) : response ? (
              <div className="min-h-[200px] w-full bg-gray-50 rounded-md p-4 overflow-auto whitespace-pre-wrap">
                {response}
              </div>
            ) : (
              <div className="min-h-[200px] w-full flex items-center justify-center bg-gray-50 rounded-md">
                <p className="text-sm text-gray-500">Submit a prompt to see the response</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        {responseHistory.length > 0 && (
          <div className="mt-4">
            <h4 className="text-sm font-medium mb-2">Recent Responses</h4>
            <div className="max-h-[150px] overflow-y-auto">
              {responseHistory.map((item, index) => (
                <div key={index} className="text-xs bg-gray-50 p-2 mb-2 rounded">
                  <div className="flex items-center">
                    <Check className="h-3 w-3 text-green-500 mr-1" />
                    <span className="font-medium">{modelConfigs[item.model].name}</span>
                  </div>
                  <p className="truncate text-gray-700 mt-1">{item.prompt}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={handleClear}>Clear</Button>
        <Button 
          disabled={loading || !prompt.trim()} 
          onClick={handleSendPrompt}
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            'Send to Model'
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}