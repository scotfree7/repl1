import React from 'react';
import { Link } from 'wouter';

const Footer = () => {
  return (
    <footer className="bg-gray-100 border-t border-gray-200 mt-8">
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <p className="text-sm text-secondary">
              &copy; {new Date().getFullYear()} ContentX | Intelligent Web Content Extraction
            </p>
          </div>
          <div className="flex space-x-4">
            <Link href="/docs">
              <a className="text-sm text-secondary hover:text-primary">Documentation</a>
            </Link>
            <Link href="/api">
              <a className="text-sm text-secondary hover:text-primary">API</a>
            </Link>
            <Link href="/privacy">
              <a className="text-sm text-secondary hover:text-primary">Privacy</a>
            </Link>
            <Link href="/terms">
              <a className="text-sm text-secondary hover:text-primary">Terms</a>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
