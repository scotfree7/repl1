import React from 'react';
import { Link } from 'wouter';
import { Menu, Bell } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Menu className="h-8 w-8" />
          <h1 className="text-xl font-semibold">OmniExtract</h1>
        </div>
        <div className="hidden md:flex items-center space-x-4">
          <Link href="/" className="px-3 py-2 rounded hover:bg-secondary transition-colors">
            Dashboard
          </Link>
          <Link href="/history" className="px-3 py-2 rounded hover:bg-secondary transition-colors">
            History
          </Link>
          <Link href="/settings" className="px-3 py-2 rounded hover:bg-secondary transition-colors">
            Settings
          </Link>
        </div>
        <div className="flex items-center space-x-2">
          <button className="p-2 rounded-full hover:bg-secondary transition-colors">
            <Bell className="h-5 w-5" />
          </button>
          <div className="w-8 h-8 rounded-full bg-info flex items-center justify-center">
            <span className="text-sm font-medium">JD</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
