import { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Copy, CheckCircle2 } from 'lucide-react';
import { undetectableService, TextStyle, TextLength } from '@/lib/undetectableService';

interface UndetectableTextGeneratorProps {
  onTextGenerated?: (text: string) => void;
}

export default function UndetectableTextGenerator({ onTextGenerated }: UndetectableTextGeneratorProps) {
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState<TextStyle>('casual');
  const [length, setLength] = useState<TextLength>('medium');
  const [generatedText, setGeneratedText] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  
  const { toast } = useToast();
  
  const handleStyleChange = (value: string) => {
    setStyle(value as TextStyle);
  };
  
  const handleLengthChange = (value: string) => {
    setLength(value as TextLength);
  };
  
  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt required",
        description: "Please enter a prompt to generate text",
        variant: "destructive",
      });
      return;
    }
    
    setLoading(true);
    
    try {
      const result = await undetectableService.generateText(prompt, style, length);
      
      if (result.status === 'success') {
        setGeneratedText(result.text);
        
        if (onTextGenerated) {
          onTextGenerated(result.text);
        }
        
        toast({
          title: "Text generated",
          description: "Undetectable text has been generated successfully",
          variant: "success",
        });
      } else {
        toast({
          title: "Generation failed",
          description: result.message || "Failed to generate undetectable text",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error generating text:', error);
      toast({
        title: "Error",
        description: "An error occurred while generating text",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleCopy = () => {
    if (!generatedText) return;
    
    navigator.clipboard.writeText(generatedText)
      .then(() => {
        setCopied(true);
        toast({
          title: "Copied",
          description: "Text copied to clipboard",
          variant: "success",
        });
        
        // Reset copied state after 2 seconds
        setTimeout(() => {
          setCopied(false);
        }, 2000);
      })
      .catch(err => {
        console.error('Failed to copy text:', err);
        toast({
          title: "Copy failed",
          description: "Failed to copy text to clipboard",
          variant: "destructive",
        });
      });
  };
  
  const handleClear = () => {
    setPrompt('');
    setGeneratedText('');
  };
  
  return (
    <Card className="w-full shadow-md">
      <CardHeader>
        <CardTitle className="text-lg font-medium">Undetectable Text Generator</CardTitle>
        <CardDescription>
          Generate human-like text that bypasses AI detection tools
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Your Prompt</label>
            <Textarea
              placeholder="Enter your prompt here..."
              className="min-h-[100px]"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Writing Style</label>
              <Select onValueChange={handleStyleChange} value={style}>
                <SelectTrigger>
                  <SelectValue placeholder="Select style" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="casual">Casual</SelectItem>
                  <SelectItem value="formal">Formal</SelectItem>
                  <SelectItem value="academic">Academic</SelectItem>
                  <SelectItem value="creative">Creative</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Length</label>
              <Select onValueChange={handleLengthChange} value={length}>
                <SelectTrigger>
                  <SelectValue placeholder="Select length" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="short">Short</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="long">Long</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {generatedText && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-sm font-medium">Generated Text</label>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 px-2"
                  onClick={handleCopy}
                  disabled={!generatedText}
                >
                  {copied ? (
                    <CheckCircle2 className="h-4 w-4 text-green-500 mr-1" />
                  ) : (
                    <Copy className="h-4 w-4 mr-1" />
                  )}
                  {copied ? 'Copied' : 'Copy'}
                </Button>
              </div>
              <div className="bg-gray-50 rounded-md p-4 min-h-[150px] whitespace-pre-wrap">
                {generatedText}
              </div>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={handleClear}>Clear</Button>
        <Button 
          onClick={handleGenerate}
          disabled={loading || !prompt.trim()}
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating...
            </>
          ) : (
            'Generate Text'
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}