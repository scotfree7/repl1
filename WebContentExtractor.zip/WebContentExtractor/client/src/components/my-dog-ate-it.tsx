import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { Import, Share2, Wand2 } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import UndetectableTextGenerator from './undetectable-text-generator';

interface MyDogAteItProps {
  onProcess: (result: string) => void;
  importedContent?: string;
  onExport?: (content: string) => void;
}

export default function MyDogAteIt({ onProcess, importedContent, onExport }: MyDogAteItProps) {
  const [entry, setEntry] = useState('');
  const [rules, setRules] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [importSource, setImportSource] = useState<string>('');
  const [activeTab, setActiveTab] = useState<string>('manual');
  const { toast } = useToast();
  
  // Handle imported content
  useEffect(() => {
    if (importedContent && importedContent.trim() !== '') {
      setEntry(importedContent);
      setImportSource('Extractor');
      
      toast({
        title: "Content imported",
        description: "Content has been imported from the Extractor",
        variant: "success",
      });
    }
  }, [importedContent]);

  const handleProcess = () => {
    if (!entry.trim()) {
      toast({
        title: "Entry required",
        description: "Please provide some text in the entry field",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    
    // Simulate processing
    setTimeout(() => {
      // Create a formatted result with the entry transformed based on rules
      let result = entry;
      
      if (rules.trim()) {
        result += `\n\n---\n\nProcessed according to rules:\n${rules}`;
      } else {
        result += "\n\n---\n\nProcessed with default rules";
      }
      
      onProcess(result);
      setIsProcessing(false);
      
      toast({
        title: "Processing complete",
        description: "Your entry has been transformed",
        variant: "success",
      });
    }, 1500);
  };

  const handleClear = () => {
    setEntry('');
    setRules('');
  };

  const handleExport = () => {
    if (!entry.trim()) {
      toast({
        title: "Nothing to export",
        description: "Please enter some text first",
        variant: "destructive",
      });
      return;
    }
    
    if (onExport) {
      onExport(entry);
      toast({
        title: "Content exported",
        description: "Your content has been exported to the Extractor",
        variant: "success",
      });
    }
  };
  
  const handleUndetectableTextGenerated = (text: string) => {
    // Update the rules field with the undetectable text
    setRules(text);
    setActiveTab('manual'); // Switch back to manual tab
    
    toast({
      title: "Undetectable text added",
      description: "The generated text has been added to the rules field",
      variant: "success",
    });
  };

  return (
    <Card className="w-full mb-6 shadow-md">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg font-medium">MyDogAteIt</CardTitle>
            <CardDescription>
              Enter your text and optional processing rules
            </CardDescription>
          </div>
          <div className="flex space-x-2">
            {importSource && (
              <Badge variant="outline" className="ml-2 text-xs bg-green-50 border-green-200">
                <Import className="h-3 w-3 mr-1" />
                Imported from {importSource}
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="flex justify-between items-center mb-1">
            <label htmlFor="entry" className="block text-sm font-medium">Entry</label>
            <div className="flex space-x-2">
              <Button
                variant="ghost" 
                size="sm" 
                className="h-6 px-2 text-xs"
                onClick={handleExport}
              >
                <Share2 className="h-3 w-3 mr-1" />
                Export to Extractor
              </Button>
            </div>
          </div>
          <Textarea
            id="entry"
            placeholder="Enter the text to process..."
            className="min-h-[120px] w-full"
            value={entry}
            onChange={(e) => setEntry(e.target.value)}
          />
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex items-center justify-between mb-2">
            <label className="block text-sm font-medium">Rules</label>
            <TabsList className="grid grid-cols-2">
              <TabsTrigger value="manual" className="text-xs px-3">
                Manual
              </TabsTrigger>
              <TabsTrigger value="undetectable" className="text-xs px-3">
                <Wand2 className="h-3 w-3 mr-1" />
                Undetectable
              </TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="manual" className="mt-0">
            <Textarea
              id="rules"
              placeholder="Enter processing rules (optional)..."
              className="min-h-[80px] w-full"
              value={rules}
              onChange={(e) => setRules(e.target.value)}
            />
          </TabsContent>
          
          <TabsContent value="undetectable" className="mt-0">
            <UndetectableTextGenerator onTextGenerated={handleUndetectableTextGenerated} />
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={handleClear}>Clear</Button>
        <Button 
          disabled={isProcessing || !entry.trim()} 
          onClick={handleProcess}
          className="bg-gradient-to-r from-primary to-blue-600 hover:from-primary hover:to-blue-500"
        >
          {isProcessing ? 'Processing...' : 'Process'}
        </Button>
      </CardFooter>
    </Card>
  );
}