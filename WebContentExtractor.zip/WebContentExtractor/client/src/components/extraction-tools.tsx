import React from 'react';
import { Zap } from 'lucide-react';

interface ExtractionToolsProps {
  selectedMethod: 'scraping' | 'browser' | 'api';
  onSelectMethod: (method: 'scraping' | 'browser' | 'api') => void;
}

const ExtractionTools: React.FC<ExtractionToolsProps> = ({ selectedMethod, onSelectMethod }) => {
  const tools = [
    {
      id: 'scraping',
      name: 'Web Scraping',
      description: 'Extracts static content from HTML structure. Fast and lightweight.',
      bestFor: 'Blogs, news sites, documentation',
      codeExample: "selector: 'article.content', method: 'GET'",
      status: selectedMethod === 'scraping' ? 'auto-selected' : 'available',
    },
    {
      id: 'browser',
      name: 'Browser Automation',
      description: 'Renders JavaScript and handles dynamic content using headless browser.',
      bestFor: 'SPAs, React/Angular sites, interactive pages',
      codeExample: "waitForSelector: '.dynamic-content', timeout: 5000",
      status: selectedMethod === 'browser' ? 'auto-selected' : 'available',
    },
    {
      id: 'api',
      name: 'API Integration',
      description: 'Uses official APIs to extract clean, structured data when available.',
      bestFor: 'Reddit, Twitter, GitHub, databases',
      codeExample: "endpoint: '/api/v1/content', auth: 'oauth'",
      status: selectedMethod === 'api' ? 'auto-selected' : 'available',
    }
  ];

  return (
    <section className="mb-8">
      <h2 className="text-lg font-semibold mb-3">Extraction Tools</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {tools.map((tool) => (
          <div 
            key={tool.id}
            className={`tool-card bg-white p-4 rounded-lg shadow-md border-2 border-transparent transition-all hover:shadow-lg ${selectedMethod === tool.id ? 'active' : ''}`}
            onClick={() => onSelectMethod(tool.id as 'scraping' | 'browser' | 'api')}
          >
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-medium">{tool.name}</h3>
              <span className={`px-2 py-1 ${tool.status === 'auto-selected' ? 'bg-success bg-opacity-20 text-success' : 'bg-gray-200 text-secondary'} text-xs rounded-full`}>
                {tool.status === 'auto-selected' ? 'Auto-selected' : 'Available'}
              </span>
            </div>
            <p className="text-sm text-secondary mb-3">{tool.description}</p>
            <div className="text-xs text-secondary mb-2 flex items-center">
              <Zap className="h-4 w-4 mr-1" />
              <span>Best for: {tool.bestFor}</span>
            </div>
            <div className="text-xs mb-3 font-mono bg-gray-100 p-2 rounded code">
              {tool.codeExample}
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <span className={`w-2 h-2 rounded-full ${selectedMethod === tool.id ? 'bg-success' : 'bg-gray-400'} mr-1`}></span>
                <span className="text-xs">{selectedMethod === tool.id ? 'Ready' : 'Standby'}</span>
              </div>
              <button className="text-xs text-info hover:underline">Configure</button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ExtractionTools;
