import React from 'react';
import { Shield, X, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ExtractionStatus as Status } from '@shared/schema';

interface ExtractionStatusProps {
  status: Status;
  url: string;
  progress: number;
  logs: string[];
  onCancel: () => void;
}

const ExtractionStatus: React.FC<ExtractionStatusProps> = ({ 
  status, 
  url, 
  progress, 
  logs,
  onCancel 
}) => {
  const getStatusLabel = () => {
    switch (status) {
      case 'analyzing': return 'Analyzing';
      case 'extracting': return 'Extracting';
      case 'complete': return 'Complete';
      case 'error': return 'Error';
      default: return 'Idle';
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'analyzing': return 'bg-info bg-opacity-10 text-info';
      case 'extracting': return 'bg-info bg-opacity-10 text-info';
      case 'complete': return 'bg-success bg-opacity-10 text-success';
      case 'error': return 'bg-destructive bg-opacity-10 text-destructive';
      default: return 'bg-gray-200 text-gray-600';
    }
  };

  const getProgressStepText = () => {
    if (status === 'analyzing') return 'Analyzing structure';
    if (status === 'extracting') return 'Extracting content';
    if (status === 'complete') return 'Extraction complete';
    if (status === 'error') return 'Extraction failed';
    return '';
  };

  return (
    <section className="mb-8">
      <h2 className="text-lg font-semibold mb-3">Extraction Status</h2>
      
      <div className="bg-white p-4 rounded-lg shadow-md">
        {/* Status indicators */}
        <div className="flex items-center mb-4">
          <div className="flex-1">
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-full bg-primary bg-opacity-10 flex items-center justify-center mr-3">
                <Shield className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Working with URL:</h3>
                <p className="text-sm text-secondary truncate">{url}</p>
              </div>
            </div>
          </div>
          <div className="flex items-center">
            <span className={`px-3 py-1 ${getStatusColor()} text-sm rounded-full mr-2`}>
              {getStatusLabel()}
            </span>
            <button 
              className="p-1 text-secondary hover:text-destructive focus:outline-none" 
              title="Cancel extraction"
              onClick={onCancel}
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
        
        {/* Progress bar */}
        <div className="mb-4">
          <Progress value={progress} className="w-full bg-gray-200 rounded-full h-2.5" />
          <div className="flex justify-between mt-1 text-xs text-secondary">
            <span>{getProgressStepText()}</span>
            <span>{progress}%</span>
          </div>
        </div>
        
        {/* Live log */}
        <div className="border border-gray-200 rounded-md p-2 bg-gray-50 h-32 overflow-y-auto font-mono text-xs mb-4">
          {logs.map((log, index) => (
            <div key={index} className={`mb-1 ${log.includes('Error') ? 'text-destructive' : log.includes('warning') ? 'text-warning' : ''}`}>
              {log}
            </div>
          ))}
        </div>
        
        {/* Action buttons */}
        <div className="flex justify-between">
          <div>
            <Button 
              variant="secondary" 
              className="px-3 py-1 bg-secondary text-white text-sm rounded hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-secondary focus:ring-opacity-50"
            >
              View details
            </Button>
            <Button 
              variant="outline" 
              className="px-3 py-1 ml-2 border border-secondary text-secondary text-sm rounded hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-secondary focus:ring-opacity-50"
            >
              Save configuration
            </Button>
          </div>
          <Button 
            variant="ghost" 
            className="px-3 py-1 text-sm text-secondary hover:text-primary focus:outline-none"
          >
            <span className="flex items-center">
              <Info className="h-4 w-4 mr-1" />
              Help
            </span>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ExtractionStatus;
