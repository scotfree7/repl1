import React from 'react';
import { Info, Globe, Database, MessageSquare, Rss, Zap, BookOpen } from 'lucide-react';

const QuickReference: React.FC = () => {
  const dataSources = [
    {
      icon: <Globe className="h-4 w-4 text-secondary" />,
      title: 'Web Pages',
      description: 'HTML-based content from blogs, news sites, documentation'
    },
    {
      icon: <Database className="h-4 w-4 text-secondary" />,
      title: 'Databases (PostgreSQL)',
      description: 'Direct database connections with query capabilities'
    },
    {
      icon: <MessageSquare className="h-4 w-4 text-secondary" />,
      title: 'Reddit',
      description: 'Posts, comments, and user data via API'
    },
    {
      icon: <Rss className="h-4 w-4 text-secondary" />,
      title: 'RSS Feeds',
      description: 'Structured content from feeds and podcasts'
    }
  ];

  const tips = [
    {
      number: '1',
      title: 'Dynamic content:',
      description: 'For sites with JavaScript-rendered content (React, Vue, etc.), use Browser Automation for better results.'
    },
    {
      number: '2',
      title: 'API-first platforms:',
      description: 'Reddit, Twitter, and GitHub work best with API integration when you have credentials.'
    },
    {
      number: '3',
      title: 'Paywall detection:',
      description: 'The system automatically attempts different methods to bypass content restrictions.'
    },
    {
      number: '4',
      title: 'CSS Selectors:',
      description: 'For precise content targeting, use Advanced Options to specify exact elements.'
    }
  ];

  return (
    <section>
      <h2 className="text-lg font-semibold mb-3">Quick Reference Guide</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Left column */}
        <div className="bg-white p-4 rounded-lg shadow-md">
          <h3 className="font-medium mb-3 flex items-center">
            <Info className="h-5 w-5 mr-1 text-info" />
            Supported Data Sources
          </h3>
          
          <div className="space-y-2">
            {dataSources.map((source, index) => (
              <div key={index} className="flex items-start">
                <div className="flex-shrink-0 w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center mr-2">
                  {source.icon}
                </div>
                <div>
                  <h4 className="font-medium text-sm">{source.title}</h4>
                  <p className="text-xs text-secondary">{source.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Right column */}
        <div className="bg-white p-4 rounded-lg shadow-md">
          <h3 className="font-medium mb-3 flex items-center">
            <Zap className="h-5 w-5 mr-1 text-info" />
            Smart Selection Tips
          </h3>
          
          <div className="space-y-3 text-sm">
            {tips.map((tip, index) => (
              <div key={index} className="flex items-start">
                <div className="flex-shrink-0 w-6 h-6 bg-success bg-opacity-20 rounded-full flex items-center justify-center mr-2 mt-0.5">
                  <span className="text-success font-medium text-xs">{tip.number}</span>
                </div>
                <p className="text-secondary">
                  <span className="font-medium text-primary">{tip.title}</span> {tip.description}
                </p>
              </div>
            ))}
            
            <div className="mt-4 pt-3 border-t border-gray-200">
              <a href="#" className="text-info hover:underline flex items-center text-sm">
                <BookOpen className="h-4 w-4 mr-1" />
                View full documentation
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default QuickReference;
