import React, { useState } from 'react';
import { Download, FileText, Search, Eye } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

interface ExtractedContentProps {
  loading: boolean;
  content?: any;
}

const ExtractedContent: React.FC<ExtractedContentProps> = ({ loading, content }) => {
  const [fontType, setFontType] = useState('Default');
  
  const handleFontChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFontType(e.target.value);
  };

  const getFontClass = () => {
    switch (fontType) {
      case 'Serif': return 'font-serif';
      case 'Sans-serif': return 'font-sans';
      case 'Monospace': return 'font-mono';
      default: return '';
    }
  };

  return (
    <section className="mb-8">
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-lg font-semibold">Extracted Content</h2>
        <div className="flex space-x-2">
          <button className="px-3 py-1 bg-white shadow rounded-md text-sm flex items-center">
            <Download className="h-4 w-4 mr-1" />
            Export
          </button>
          <button className="px-3 py-1 bg-white shadow rounded-md text-sm flex items-center">
            <FileText className="h-4 w-4 mr-1" />
            View Raw
          </button>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        {/* Content toolbar */}
        <div className="border-b border-gray-200 px-4 py-2 flex items-center justify-between bg-gray-50">
          <div className="flex items-center">
            <button className="p-1 rounded hover:bg-gray-200 mr-1">
              <FileText className="h-5 w-5 text-secondary" />
            </button>
            <button className="p-1 rounded hover:bg-gray-200 mr-1">
              <Search className="h-5 w-5 text-secondary" />
            </button>
            <span className="text-sm text-secondary">Reading view</span>
          </div>
          <div className="flex items-center">
            <button className="p-1 rounded hover:bg-gray-200 mr-1 text-sm">
              <Eye className="h-5 w-5 text-secondary" />
            </button>
            <span className="text-sm text-secondary mr-2">Font:</span>
            <select 
              className="text-sm border-gray-200 rounded p-1"
              value={fontType}
              onChange={handleFontChange}
            >
              <option>Default</option>
              <option>Serif</option>
              <option>Sans-serif</option>
              <option>Monospace</option>
            </select>
          </div>
        </div>
        
        {/* Content display area */}
        <div className={`p-6 max-w-3xl mx-auto ${getFontClass()}`}>
          {loading ? (
            <>
              <Skeleton className="h-10 w-3/4 mb-4" />
              <Skeleton className="h-5 w-1/3 mb-6" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-5/6 mb-6" />
              <Skeleton className="h-6 w-1/2 mb-3" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-4/5 mb-6" />
              <Skeleton className="h-20 w-full mb-6" />
              <Skeleton className="h-6 w-1/2 mb-3" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-full mb-2" />
            </>
          ) : content ? (
            <>
              <h1 className="text-2xl font-bold mb-4">{content.title || "The Future of AI in 2023 and Beyond"}</h1>
              <p className="mb-3 text-gray-500 text-sm">{content.byline || "By ContentX | Published: " + new Date().toLocaleDateString()}</p>
              
              <div dangerouslySetInnerHTML={{ __html: content.content || `
                <p class="mb-3">Artificial intelligence continues to evolve at a breathtaking pace. As we move through 2023, several key trends are emerging that will shape how AI influences our daily lives and transforms industries.</p>
                
                <h2 class="text-xl font-semibold mt-6 mb-3">Generative AI Goes Mainstream</h2>
                <p class="mb-3">Text-to-image models like DALL-E, Midjourney, and Stable Diffusion have captivated the public imagination. These tools are now being integrated into creative workflows across industries, from advertising to product design.</p>
                
                <p class="mb-3">Meanwhile, large language models (LLMs) like GPT-4 are becoming increasingly sophisticated, enabling more natural human-computer interaction and opening new possibilities for content creation and knowledge work.</p>
                
                <div class="my-6 p-4 bg-gray-50 border-l-4 border-info">
                  <p class="italic">"AI isn't just changing what we can do—it's changing how we think about what's possible."</p>
                </div>
                
                <h2 class="text-xl font-semibold mt-6 mb-3">Ethical AI Takes Center Stage</h2>
                <p class="mb-3">As AI becomes more pervasive, questions about bias, transparency, and accountability are gaining prominence. Regulatory frameworks are beginning to emerge, with the EU's AI Act leading the way in establishing guidelines for responsible AI development.</p>
                
                <p class="mb-3">Companies are increasingly adopting ethical AI principles and implementing governance structures to ensure their AI systems are fair, transparent, and beneficial.</p>
              `}} />
            </>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500">No content extracted yet.</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default ExtractedContent;
