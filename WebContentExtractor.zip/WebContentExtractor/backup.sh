
#!/bin/bash

# Enhanced emergency backup script with auto-save verification
# Usage: bash backup.sh [github_repo_url]

echo "🚀 Starting emergency backup process..."

# Create timestamp for backups
TIMESTAMP=$(date +"%Y-%m-%d_%H-%M-%S")
BACKUP_FILENAME="project-backup-${TIMESTAMP}.zip"

# Function to create backup (using tar instead of zip)
create_zip_backup() {
  echo "📦 Creating backup archive..."
  # Use tar instead of zip (more commonly available on Linux systems)
  TAR_FILENAME="project-backup-${TIMESTAMP}.tar.gz"
  
  # Check if we should create a new backup or verify existing ones
  if [ "$VERIFY_ONLY" != "true" ]; then
    tar --exclude="node_modules" \
        --exclude=".git" \
        --exclude="dist" \
        --exclude="*.zip" \
        --exclude="*.tar.gz" \
        -czf "${TAR_FILENAME}" .
    
    echo "✅ Backup archive created: ${TAR_FILENAME}"
    echo "📋 Download this file from the Files panel to save your work."
    
    # Create a verification file to track downloaded backups
    echo "${TAR_FILENAME}" >> .backup_history
  fi
  
  # List existing backups that need to be downloaded
  echo "📝 Checking for backups that need to be downloaded..."
  if [ -f .backup_history ]; then
    echo "The following backups are available:"
    cat .backup_history | while read backup_file; do
      if [ -f "$backup_file" ]; then
        echo "  - $backup_file (Not yet downloaded to your desktop)"
      fi
    done
    echo ""
    echo "💾 To download a backup to your desktop:"
    echo "  1. Right-click on the file in the Files panel"
    echo "  2. Select 'Download'"
    echo "  3. Save to your Desktop folder"
    echo ""
  fi
}

# Function to verify if backups have been downloaded
verify_downloads() {
  # We can only track if files exist on Replit, not if they've been downloaded locally
  # So we'll provide clear instructions for the user
  echo "🔍 Checking for existing backup files..."
  
  # Count how many backup files exist
  BACKUP_COUNT=$(ls -1 project-backup-*.tar.gz 2>/dev/null | wc -l)
  
  if [ "$BACKUP_COUNT" -gt 0 ]; then
    echo "Found $BACKUP_COUNT backup archives in your project."
    echo "To ensure these are saved to your desktop:"
    
    # List each backup file with instructions
    ls -1t project-backup-*.tar.gz | while read backup; do
      echo "  → $backup"
    done
    
    echo ""
    echo "📥 DOWNLOAD INSTRUCTIONS:"
    echo "  1. Find the backup file in the Files panel (left side of Replit)"
    echo "  2. Right-click on the file and select 'Download'"
    echo "  3. In your browser's download dialog, select 'Save to Desktop'"
    echo ""
  else
    echo "No backup archives found. Creating a new one..."
  fi
}

# GitHub backup function
github_backup() {
  GITHUB_URL=$1
  
  if [ -z "$GITHUB_URL" ]; then
    echo "⚠️ No GitHub URL provided. Please provide a valid repository URL."
    echo "Example: ./backup.sh https://github.com/username/repo.git"
    return 1
  fi
  
  echo "🔄 Attempting GitHub backup to: $GITHUB_URL"
  
  # Check if git is initialized
  if [ ! -d ".git" ]; then
    echo "📦 Initializing git repository..."
    git init
  fi

  # Configure git if needed
  if [ -z "$(git config user.email)" ]; then
    echo "⚙️ Configuring git user..."
    git config user.email "emergency-backup@example.com"
    git config user.name "Emergency Backup"
  fi

  # Add all files excluding certain directories
  echo "📝 Adding files to git..."
  git add .
  git reset -- node_modules/ dist/ .git/ "*.zip"

  # Commit changes
  echo "💾 Committing changes..."
  git commit -m "Emergency backup ${TIMESTAMP}" || {
    echo "ℹ️ No changes to commit or commit failed."
  }

  # Handle remote
  if ! git remote | grep -q "origin"; then
    echo "🔗 Adding remote origin..."
    git remote add origin $GITHUB_URL
  else
    echo "🔄 Updating remote URL..."
    git remote set-url origin $GITHUB_URL
  fi

  # Push to GitHub
  echo "☁️ Pushing to GitHub..."
  git push -u origin main --force || {
    echo "❌ Failed to push to GitHub. Check your repository URL and permissions."
    echo "🔄 Falling back to ZIP backup..."
    return 1
  }

  echo "✅ GitHub backup complete! Your code is now safe on GitHub."
  echo "📋 Repository URL: $GITHUB_URL"
  return 0
}

# Main execution flow

# Check if we're just verifying downloads
if [ "$1" == "--verify" ]; then
  VERIFY_ONLY=true
  verify_downloads
else
  # First check for existing backups
  verify_downloads
  
  # Create a ZIP backup
  VERIFY_ONLY=false
  create_zip_backup
  
  # Try GitHub backup if URL is provided
  if [ -n "$1" ] && [ "$1" != "--verify" ]; then
    github_backup "$1" || echo "⚠️ GitHub backup failed, but tar.gz backup was successful."
  else
    echo "ℹ️ No GitHub URL provided. Only tar.gz backup was created."
    echo "To backup to GitHub:"
    echo "1. First create a repository on GitHub at https://github.com/new"
    echo "2. Then run: ./backup.sh https://github.com/yourusername/your-repo-name.git"
  fi
fi

echo ""
echo "🔐 EMERGENCY BACKUP COMPLETED 🔐"
echo "If you need to restore this project on another device:"
echo "1. Download the tar.gz file from the Files panel to your desktop"
echo "2. Create a new Repl and upload the backup, or"
echo "3. If GitHub backup succeeded, create a new Repl and import from GitHub"
echo ""
echo "To verify if backups have been downloaded, run: ./backup.sh --verify"
