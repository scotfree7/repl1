import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const extractionHistory = pgTable("extraction_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  url: text("url").notNull(),
  method: text("method").notNull(),
  status: text("status").notNull(),
  extractedContent: text("extracted_content"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  metadata: jsonb("metadata"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertExtractionHistorySchema = createInsertSchema(extractionHistory).omit({
  id: true,
  createdAt: true,
});

export const extractionRequestSchema = z.object({
  url: z.string().url(),
  method: z.enum(["auto", "scraping", "browser", "api"]).default("auto"),
  selector: z.string().optional(),
  removeAds: z.boolean().default(true),
  includeImages: z.boolean().default(true),
  dataSource: z.enum(["webpage", "reddit", "postgres", "rss"]).default("webpage"),
  outputFormat: z.enum(["formatted", "json", "html", "markdown"]).default("formatted"),
});

export type ExtractionRequest = z.infer<typeof extractionRequestSchema>;
export type ExtractionStatus = "idle" | "analyzing" | "extracting" | "complete" | "error";
export type ExtractionMethod = "scraping" | "browser" | "api" | "auto";
export type DataSource = "webpage" | "reddit" | "postgres" | "rss";
export type OutputFormat = "formatted" | "json" | "html" | "markdown";

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertExtractionHistory = z.infer<typeof insertExtractionHistorySchema>;
export type ExtractionHistory = typeof extractionHistory.$inferSelect;
