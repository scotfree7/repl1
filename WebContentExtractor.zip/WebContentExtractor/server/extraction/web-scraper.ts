import { ContentExtractor, ExtractedContent } from "./index";
import { ExtractionRequest } from "@shared/schema";
import fetch from "node-fetch";
import * as cheerio from "cheerio";

export class WebScraper implements ContentExtractor {
  async extract(request: ExtractionRequest): Promise<ExtractedContent> {
    try {
      const response = await fetch(request.url);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch URL: ${response.status} ${response.statusText}`);
      }
      
      const html = await response.text();
      const $ = cheerio.load(html);
      
      // Try to extract the content using the provided selector or fallback to smart detection
      const selector = request.selector || this.detectMainContentSelector($);
      
      // Extract the title
      const title = $('title').text().trim() || $('h1').first().text().trim();
      
      // Extract the content
      let contentHtml = '';
      
      if (selector) {
        contentHtml = $(selector).html() || '';
      } else {
        // Fallback to common article patterns
        const possibleContentElements = [
          'article', 
          'main', 
          '.content', 
          '.article', 
          '.post', 
          '#content',
          '.main-content',
          'section.content',
          '[role="main"]'
        ];
        
        for (const element of possibleContentElements) {
          if ($(element).length) {
            contentHtml = $(element).html() || '';
            break;
          }
        }
        
        // If still no content, try to get the body minus the header, footer, nav, etc.
        if (!contentHtml) {
          $('header, footer, nav, aside, .sidebar, .ads, .advertisement, script, style').remove();
          contentHtml = $('body').html() || '';
        }
      }
      
      // Remove ads and tracking if requested
      if (request.removeAds) {
        const $ = cheerio.load(contentHtml);
        $('.ad, .ads, .advertisement, [id*="google"], [class*="sponsor"], [id*="banner"], [class*="banner"], iframe').remove();
        contentHtml = $.html();
      }
      
      // Remove images if not requested
      if (!request.includeImages) {
        const $ = cheerio.load(contentHtml);
        $('img').remove();
        contentHtml = $.html();
      }
      
      // Try to extract author/byline
      const bylineSelectors = [
        '.author', 
        '.byline', 
        '.meta .author', 
        '[rel="author"]',
        '.entry-meta .author',
        '.post-meta .author'
      ];
      
      let byline = '';
      for (const selector of bylineSelectors) {
        if ($(selector).length) {
          byline = $(selector).text().trim();
          break;
        }
      }
      
      return {
        title,
        content: contentHtml,
        byline,
        url: request.url,
        extractedAt: new Date(),
        method: 'web-scraping',
        metadata: {
          selector: selector || 'auto-detected',
          contentLength: contentHtml.length,
          format: request.outputFormat
        }
      };
    } catch (error) {
      console.error('Web scraping error:', error);
      throw new Error(`Failed to extract content: ${error.message}`);
    }
  }
  
  getMethodName(): string {
    return 'Web Scraping';
  }
  
  private detectMainContentSelector($: cheerio.CheerioAPI): string | null {
    // Analysis logic to find the most likely content container
    // This is a simplified version - real implementation would be more sophisticated
    
    // Check for common article patterns and score them
    const candidates = [
      { selector: 'article', score: 10 },
      { selector: 'main', score: 8 },
      { selector: '.content, .article-content, .post-content', score: 7 },
      { selector: '.article, .post, #content', score: 6 },
      { selector: 'section.content, [role="main"]', score: 5 },
      { selector: '#main, .main', score: 4 }
    ];
    
    for (const candidate of candidates) {
      const elements = $(candidate.selector);
      
      if (elements.length === 0) continue;
      
      // Score based on text content length
      const textLength = elements.text().length;
      if (textLength > 1000) {
        return candidate.selector;
      }
    }
    
    // If no good candidates found, return null and let the extraction method use fallbacks
    return null;
  }
}
