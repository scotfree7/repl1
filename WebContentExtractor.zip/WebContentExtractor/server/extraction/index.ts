import { ExtractionRequest } from "@shared/schema";

export interface ContentExtractor {
  extract(request: ExtractionRequest): Promise<ExtractedContent>;
  getMethodName(): string;
}

export interface ExtractedContent {
  title?: string;
  content: string;
  byline?: string;
  url: string;
  extractedAt: Date;
  method: string;
  metadata?: Record<string, any>;
}

// Used for storing extraction results in-memory for demo purposes
// In a real app, this would be in a database
declare global {
  namespace NodeJS {
    interface Global {
      extractionResult?: ExtractedContent;
      extractionStatus?: Record<string, string>;
    }
  }
}
