import { ContentExtractor } from "./index";
import { WebScraper } from "./web-scraper";
import { BrowserAutomation } from "./browser-automation";
import { ApiIntegration } from "./api-integration";
import { ExtractionMethod, DataSource } from "@shared/schema";

/**
 * Factory function to get the appropriate extractor based on method
 * If method is 'auto', it will intelligently select the best method
 */
export function getExtractor(method: ExtractionMethod, dataSource: DataSource): ContentExtractor {
  switch (method) {
    case 'scraping':
      return new WebScraper();
    case 'browser':
      return new BrowserAutomation();
    case 'api':
      return new ApiIntegration(dataSource);
    case 'auto':
      return selectBestExtractor(dataSource);
    default:
      return new WebScraper(); // Default to scraping
  }
}

/**
 * Intelligently select the best extraction method based on the data source
 */
function selectBestExtractor(dataSource: DataSource): ContentExtractor {
  // Select the best method based on the data source
  switch (dataSource) {
    case 'reddit':
    case 'postgres':
    case 'rss':
      return new ApiIntegration(dataSource);
    case 'webpage':
    default:
      // For webpages, we'll default to scraping for now
      // In a real implementation, this would analyze the URL to determine
      // if it's a JavaScript-heavy site that needs browser automation
      return new WebScraper();
  }
}

/**
 * Analyze a URL to determine the most appropriate extraction method
 * This would be used for more sophisticated auto-detection
 */
export function analyzeUrl(url: string): ExtractionMethod {
  // Check for known data sources that work best with API integration
  if (url.includes('reddit.com') || 
      url.includes('twitter.com') || 
      url.includes('api.')) {
    return 'api';
  }
  
  // Check for known JavaScript-heavy sites that need browser automation
  if (url.includes('facebook.com') || 
      url.includes('instagram.com') ||
      url.includes('linkedin.com') ||
      url.includes('dynamic-content')) {
    return 'browser';
  }
  
  // Default to web scraping for most sites
  return 'scraping';
}
