import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { extractionRequestSchema } from "../shared/schema";
import { getExtractor } from "./extraction/extractor-factory";
import perplexityRouter from "./routes/perplexity";
import undetectableRouter from "./routes/undetectable";

export async function registerRoutes(app: Express): Promise<Server> {
  // Register the Perplexity API routes
  app.use('/api/perplexity', perplexityRouter);
  
  // Register the Undetectable API routes
  app.use('/api/undetectable', undetectableRouter);
  // Extraction API endpoints
  app.post('/api/extract', async (req, res) => {
    try {
      const validationResult = extractionRequestSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: 'Invalid extraction request',
          errors: validationResult.error.errors 
        });
      }
      
      const extractionRequest = validationResult.data;
      
      // Get the appropriate extractor based on method or auto-detect
      const extractor = getExtractor(extractionRequest.method, extractionRequest.dataSource);
      
      // Start extraction asynchronously to avoid blocking
      // In a real app, this would likely use a job queue or WebSockets for progress updates
      extractor.extract(extractionRequest)
        .then(result => {
          // Store the result for retrieval later
          global.extractionResult = result;
        })
        .catch(error => {
          console.error('Extraction error:', error);
        });
      
      // Return immediately with status - client will poll for results
      res.json({ 
        message: 'Extraction started',
        status: 'analyzing',
        method: extractor.getMethodName()
      });
    } catch (error) {
      console.error('Extract API error:', error);
      res.status(500).json({ message: 'Internal server error during extraction' });
    }
  });

  // Get the extracted content
  app.get('/api/extract/content', (req, res) => {
    if (!global.extractionResult) {
      return res.status(404).json({ message: 'No extraction result available' });
    }
    
    res.json(global.extractionResult);
  });

  // Get extraction status
  app.get('/api/extract/status', (req, res) => {
    const url = req.query.url as string;
    
    if (!url) {
      return res.status(400).json({ message: 'URL parameter is required' });
    }
    
    // Mock status based on global state - in a real app this would be stored in a database
    const status = global.extractionStatus?.[url] || 'idle';
    
    res.json({ status });
  });

  // Get extraction methods available for a URL
  app.get('/api/extract/methods', async (req, res) => {
    const url = req.query.url as string;
    
    if (!url) {
      return res.status(400).json({ message: 'URL parameter is required' });
    }
    
    try {
      // Determine available methods for the given URL
      const availableMethods = [
        { id: 'scraping', name: 'Web Scraping', recommended: true },
        { id: 'browser', name: 'Browser Automation', recommended: false },
        { id: 'api', name: 'API Integration', recommended: false }
      ];
      
      res.json({ methods: availableMethods });
    } catch (error) {
      console.error('Extract methods API error:', error);
      res.status(500).json({ message: 'Failed to get available extraction methods' });
    }
  });

  const httpServer = createServer(app);
  
  return httpServer;
}
