import { ExtractedContent } from '../extraction';

declare global {
  var extractionResult: ExtractedContent | undefined;
  var extractionStatus: Record<string, string> | undefined;
}