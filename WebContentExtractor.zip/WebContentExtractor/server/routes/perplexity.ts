import { Router } from 'express';
import { z } from "zod";

const perplexityRouter = Router();

// Schema for validating Perplexity API requests
const perplexityRequestSchema = z.object({
  model: z.enum([
    "llama-3.1-sonar-small-128k-online", 
    "llama-3.1-sonar-large-128k-online", 
    "llama-3.1-sonar-huge-128k-online"
  ]).default("llama-3.1-sonar-small-128k-online"),
  messages: z.array(z.object({
    role: z.enum(["system", "user", "assistant"]),
    content: z.string()
  })),
  temperature: z.number().min(0).max(1).optional().default(0.7),
  max_tokens: z.number().optional(),
  stream: z.boolean().optional().default(false)
});

// Route for the Perplexity API
perplexityRouter.post('/chat/completions', async (req, res) => {
  try {
    // Validate the request body
    const validatedData = perplexityRequestSchema.parse(req.body);
    
    // Check if API key exists in environment variables
    const apiKey = process.env.PERPLEXITY_API_KEY;
    
    if (apiKey) {
      // Real API call logic would go here
      // For now, we'll simulate the response
      return simulateResponse(validatedData, res);
    } else {
      // If no API key, use simulation mode
      return simulateResponse(validatedData, res);
    }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        error: "Invalid request data", 
        details: error.errors 
      });
    }
    
    console.error("Perplexity API error:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

// Function to simulate a Perplexity API response
function simulateResponse(data: z.infer<typeof perplexityRequestSchema>, res: any) {
  // Get the last user message
  const lastUserMessage = data.messages.findLast(msg => msg.role === "user")?.content || "";
  
  // Analyze the query type based on keywords
  const queryType = analyzeQueryType(lastUserMessage);
  
  // Generate a simulated response
  const simulatedResponse = {
    id: `sim-${Date.now().toString(36)}`,
    model: data.model,
    object: "chat.completion",
    created: Math.floor(Date.now() / 1000),
    citations: [
      "https://example.com/reference1",
      "https://example.com/reference2"
    ],
    choices: [
      {
        index: 0,
        finish_reason: "stop",
        message: {
          role: "assistant",
          content: generateContent(lastUserMessage, queryType)
        },
        delta: {
          role: "assistant",
          content: ""
        }
      }
    ],
    usage: {
      prompt_tokens: countTokens(data.messages),
      completion_tokens: 150,
      total_tokens: countTokens(data.messages) + 150
    }
  };
  
  // Add a small delay to simulate API call
  setTimeout(() => {
    res.json(simulatedResponse);
  }, 1000);
}

// Analyze what type of query this is
function analyzeQueryType(query: string): 'factual' | 'creative' | 'code' | 'analysis' {
  const lowerQuery = query.toLowerCase();
  if (lowerQuery.includes('code') || lowerQuery.includes('function') || lowerQuery.includes('programming')) {
    return 'code';
  } else if (lowerQuery.includes('explain') || lowerQuery.includes('analyze') || lowerQuery.includes('compare')) {
    return 'analysis';
  } else if (lowerQuery.includes('create') || lowerQuery.includes('write') || lowerQuery.includes('design')) {
    return 'creative';
  } else {
    return 'factual';
  }
}

// Generate appropriate content based on the query type
function generateContent(query: string, queryType: 'factual' | 'creative' | 'code' | 'analysis'): string {
  const truncatedQuery = query.length > 50 ? query.substring(0, 50) + "..." : query;
  
  switch (queryType) {
    case 'factual':
      return `[Simulated Perplexity Response - Factual]\n\nBased on your factual query: "${truncatedQuery}"\n\nHere's what I found from reliable sources:\n\n1. According to recent research, this topic has several key aspects worth noting.\n2. Experts in the field generally agree on the main principles.\n3. There are some interesting statistics that provide context: approximately 78% of cases follow the expected pattern.\n\nWould you like me to explore any specific aspect of this topic in more detail?`;
      
    case 'creative':
      return `[Simulated Perplexity Response - Creative]\n\nI notice you're looking for creative content with: "${truncatedQuery}"\n\nHere's a creative approach to your request:\n\nThe concept you're exploring has multiple creative applications. Consider approaching it from these perspectives:\n\n- A novel interpretation that focuses on the aesthetic elements\n- An innovative framework that combines traditional and modern techniques\n- A unique methodology that emphasizes collaborative development\n\nThis creative direction could open up new possibilities for your project.`;
      
    case 'code':
      return `[Simulated Perplexity Response - Code]\n\nFor your coding query: "${truncatedQuery}"\n\n\`\`\`javascript\n// Here's a sample implementation:\nfunction processData(input) {\n  const result = input.map(item => {\n    return {\n      id: item.id,\n      processed: item.value * 2,\n      timestamp: new Date().toISOString()\n    };\n  });\n  \n  return result.filter(item => item.processed > 10);\n}\n\`\`\`\n\nThis code demonstrates a basic implementation. You would need to adapt it to your specific requirements.`;
      
    case 'analysis':
      return `[Simulated Perplexity Response - Analysis]\n\nAnalyzing your query: "${truncatedQuery}"\n\nFrom multiple perspectives:\n\n1. Historical Context:\n   - The subject evolved significantly over the past decade\n   - Key turning points occurred in 2019 and 2022\n\n2. Comparative Analysis:\n   - Approach A offers better performance but lower flexibility\n   - Approach B prioritizes user experience at the cost of efficiency\n   - Approach C represents a balanced middle ground\n\n3. Future Implications:\n   - Emerging trends suggest a shift toward more integrated solutions\n   - Research indicates 3 potential development pathways\n\nWould you like a deeper analysis of any specific aspect?`;
  }
}

// Simple token counter (would be replaced with a proper tokenizer in production)
function countTokens(messages: any[]): number {
  return messages.reduce((count, msg) => {
    return count + Math.ceil(msg.content.length / 4);
  }, 0);
}

export default perplexityRouter;