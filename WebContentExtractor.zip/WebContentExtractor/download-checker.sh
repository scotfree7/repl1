
#!/bin/bash

# A helper script to check if backups have been downloaded and guide the user
# Usage: ./download-checker.sh

echo "🔍 Checking for backup files in your project..."

# Find all backup files
BACKUPS=$(ls -1 project-backup-*.tar.gz 2>/dev/null)
BACKUP_COUNT=$(echo "$BACKUPS" | wc -l)

if [ -z "$BACKUPS" ]; then
  echo "No backup files found. Run ./backup.sh to create one first."
  exit 1
fi

echo "Found $BACKUP_COUNT backup files:"
echo "$BACKUPS" | nl

echo ""
echo "To download these backups to your desktop:"
echo "1. In the Files panel (left side of Replit),"
echo "2. Right-click on each backup file"
echo "3. Select 'Download'"
echo "4. Choose to save to your Desktop"
echo ""
echo "Once downloaded, you can verify the file exists on your desktop by checking your desktop folder."
echo ""
echo "For automatic backup creation and verification, run: ./backup.sh"
